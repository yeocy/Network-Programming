package Chat;

public class Friend {
   String id;
   String name;
   String nickname;   
   String birth;
   String email;
   String info;
   String number;
   String online;
   String last_date;
   
   public Friend(String id, String nickname,String name,String birth,String email, String info, String number, String online,String last_date) {
      this.id = id;
      this.nickname = nickname;
      this.name = name;
      this.birth = birth;
      this.email = email;
      this.info = info;
      this.number = number;
      this.online = online;
      this.last_date = last_date;
   }

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getNickname() {
	return nickname;
}

public void setNickname(String nickname) {
	this.nickname = nickname;
}

public String getBirth() {
	return birth;
}

public void setBirth(String birth) {
	this.birth = birth;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getInfo() {
	return info;
}

public void setInfo(String info) {
	this.info = info;
}

public String getNumber() {
	return number;
}

public void setNumber(String number) {
	this.number = number;
}

public String getOnline() {
	return online;
}

public void setOnline(String online) {
	this.online = online;
}

public String getLast_date() {
	return last_date;
}

public void setLast_date(String last_date) {
	this.last_date = last_date;
}


}