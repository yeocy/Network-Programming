package Chat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBConnection {
	private Connection con;
	private Statement st;
	private ResultSet rs;
	
	String DBID = "root";
	String DBPW = "projectGroup6";
	String DBName = "userinfo";
    String TableName = "information";
    String SQL;
			
	public DBConnection() {
		
		InfoConfig i = new InfoConfig();
		i.getInfo();
		
		String IP = i.Ip;
		String Port = i.Port;
		
		try {			
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+IP+":"+Port+"/"+DBName+"?characterEncoding=UTF-8&serverTimezone=UTC";
			con = DriverManager.getConnection(url,DBID,DBPW);
			st = con.createStatement();
			
		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����: "+e.getMessage());
		}
	}
	
	public void CreateTable() {
		try {
			SQL = "CREATE TABLE "+TableName +" (ID VARCHAR(20) PRIMARY KEY NOT NULL,NickName VARCHAR(20) NOT NULL,Name VARCHAR(20) NOT NULL,Birth DATE NOT NULL,Email VARCHAR(30) NOT NULL,PhoneNum VARCHAR(13),StatusMessage VARCHAR(100),ConnectionStatus VARCHAR(7) DEFAULT 'offline',PW VARCHAR(100) NOT NULL)";
			st.executeUpdate(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean checkID(String ID) { //DB�� ID�� �����ϸ� true, �׷��� ������ false�� return.
		try {
			SQL = "SELECT * FROM "+TableName+" WHERE ID = '"+ID+"'";
			rs = st.executeQuery(SQL);
			if(rs.next()) {return true;}
		} catch (Exception e) {
			e.printStackTrace();
		} return false;
	}
	public void createAccount(String ID,String NickName,String Name,String Birth,String Email,String PhoneNum,String StatusMessage,String PW) {
		//���� ����. DB�� �Է��� �ʼ� ��ҵ��� �Է¹޴´�.
		try {
			SQL = "INSERT INTO "+TableName+"(ID,NickName,Name,Birth,Email,PhoneNum,StatusMessage,PW) "
					+"VALUES ('"+ID+"','"+NickName+"','"+Name+"','"+Birth+"','"+Email+"','"+PhoneNum+"','"+StatusMessage+"',SHA1('"+PW+"'))";
			st.executeUpdate(SQL);
			SQL = "CREATE TABLE "+ID+"friends (FriendID VARCHAR(20) PRIMARY KEY NOT NULL)";
			st.executeUpdate(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	} 
	public void cancelAccount(String ID) {
		//���� ����.
		try {
			SQL="DELETE FROM "+TableName+" WHERE ID='"+ID+"'";
			st.executeUpdate(SQL);
			SQL="DROP TABLE "+ID+"friends";
			st.executeUpdate(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public boolean logIn(String ID, String PW) { // �α��� �����ϸ� true ����
		//�α���
		try {
			SQL = "SELECT * FROM "+TableName+" WHERE ID='"+ID+"' and PW=SHA1('"+PW+"')";
			rs = st.executeQuery(SQL);
			if(rs.next()==true) {System.out.println("login succes");return true;}
			else {System.out.println("login failed");}
		} catch (Exception e) {
			e.printStackTrace();
		} return false;
	}
	public void logOut(String ID, String PW) { //�����ؾߵ�. �ϴ� ������
		//�α׾ƿ�
		try {
			;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void updateConnectionStatus(String ID) { 
		//���� ���� ������Ʈ
		try {
			SQL = "SELECT * FROM "+TableName+" WHERE connectionStatus='offline' and ID='"+ID+"'";
			rs = st.executeQuery(SQL);
			if(rs.next()==true) {
				//���� ���°� offline�̸� online���� ������Ʈ
				SQL = "UPDATE "+ TableName+" SET connectionStatus='online' WHERE ConnectionStatus='offline'";
			} else {
				//���� ���°� online�̸� online���� ������Ʈ
				SQL = "UPDATE "+ TableName+" SET connectionStatus='offline' WHERE ConnectionStatus='online'";
			}
			st.executeUpdate(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public String getConnectionStatus(String ID) { //���� ������ return.(online/offline)
		String cs=null; //connection status
		try {
			SQL = "SELECT ConnectionStatus FROM "+TableName+" WHERE ID='"+ID+"'";
			rs = st.executeQuery(SQL);
			while(rs.next()) {
				cs = rs.getString("ConnectionStatus");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return cs;
	}
	public void addFriends(String myID,String FrID) {
		try {
			if(checkID(FrID)==true) {
				SQL = "INSERT INTO "+myID+"friends (FriendID) SELECT ID from "+TableName+" where ID='"+FrID+"'";
				st.executeUpdate(SQL);
			} else { throw new SQLException();}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public String getStatusMessage(String ID) { //���� �޼���(������ �Ѹ���)�� return.
		String sm=null; //status message
		try {
			SQL = "SELECT StatusMessage FROM "+TableName+" WHERE ID='"+ID+"'";
			rs = st.executeQuery(SQL);
			while(rs.next()) {
				sm = rs.getString("StatusMessage");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return sm;
	}
	public void updateStatusMessage(String ID,String newmsg) {
		//���¸޼���(������ �Ѹ���)�� update.
		try{
			SQL = "UPDATE "+ TableName+" SET StatusMessage='"+newmsg+"' WHERE ID='"+ID+"'";
			st.executeUpdate(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public String getPhoneNumber(String ID) { //��ȭ��ȣ�� return.
		String pn=null; //phone number
		try {
			SQL = "SELECT PhoneNum FROM "+TableName+" WHERE ID='"+ID+"'";
			rs = st.executeQuery(SQL);
			while(rs.next()) {
				pn = rs.getString("PhoneNum");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return pn;
	}
	public String getBirthDay(String ID) { //��������� return.
		String bth=null; //birthday
		try {
			SQL = "SELECT Birth FROM "+TableName+" WHERE ID='"+ID+"'";
			rs = st.executeQuery(SQL);
			while(rs.next()) {
				bth = rs.getString("Birth");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return bth;
	}
	public String getEmail(String ID) { //�̸����� return.
		String mail=null;
		try {
			SQL = "SELECT Email FROM "+TableName+" WHERE ID='"+ID+"'";
			rs = st.executeQuery(SQL);
			while(rs.next()) {
				mail = rs.getString("Email");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return mail;
	}
	public void updateName(String ID,String newmsg) { //����� �̸��� ������Ʈ�Ѵ�.
		try{
			SQL = "UPDATE "+ TableName+" SET Name='"+newmsg+"' WHERE ID='"+ID+"'";
			st.executeUpdate(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void searchID(String search) { //ID �˻�
		String ID;
		try {
			SQL = "SELECT * FROM "+TableName+" WHERE ID LIKE '%"+search+"%'";
			rs = st.executeQuery(SQL);
			while(rs.next()) {
				ID = rs.getString("ID");
				System.out.println(ID); 
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}